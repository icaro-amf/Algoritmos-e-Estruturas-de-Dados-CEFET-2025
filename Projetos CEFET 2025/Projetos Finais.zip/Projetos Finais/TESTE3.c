/****************

LAED1 - Projeto (Parte I) - Busca por padrão em sequência

Alunos: ANDRÉ JUNQUEIRA ESPÍNDOLA BOTELHO
        ICARO ALVES MOTA FONSECA

Data:   06/11/2024

****************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_MAPEAR 1000

// Função para preencher um vetor para o maior prefixo que é sufixo
void prefixoSufixoNoArray(int *substring, int tamanhoPadrao, int *prefixoSufixo)
{
    int tamanho = 0;
    prefixoSufixo[0] = 0;
    int i = 1;

    while (i < tamanhoPadrao)
    {
        if (substring[i] == substring[tamanho])
        {
            tamanho++;
            prefixoSufixo[i] = tamanho;
            i++;
        }
        else
        {
            if (tamanho != 0)
            {
                tamanho = prefixoSufixo[tamanho - 1];
            }
            else
            {
                prefixoSufixo[i] = 0;
                i++;
            }
        }
    }
}

// Função principal de busca KMP
// Modificação: agora retorna o índice de início da ocorrência encontrada em 'txt' (ou -1 se não encontrado).
int KMP(int *substring, int tamanhoPadrao, int *txt, int tamanhoTexto)
{
    int *prefixoSufixo = (int *)malloc(sizeof(int) * tamanhoPadrao);
    prefixoSufixoNoArray(substring, tamanhoPadrao, prefixoSufixo);

    int i = 0;
    int j = 0;
    int verificador = -1;

    while (i < tamanhoTexto)
    {
        if (substring[j] == txt[i])
        {
            j++;
            i++;
        }

        if (j == tamanhoPadrao)
        {
            verificador = i - j;
            j = prefixoSufixo[j - 1];
            break;
        }
        else if (i < tamanhoTexto && substring[j] != txt[i])
        {
            if (j != 0)
                j = prefixoSufixo[j - 1];
            else
                i++;
        }
    }

    free(prefixoSufixo);
    return verificador;
}

/*
  Observações / decisões da implementacao da Parte II (comentarios novos, mantive os originais):

  ***ATUALIZAÇÃO IMPORTANTE (SOLUÇÃO DEFINITIVA)***
  - A orientação da pista NÃO deve depender do tamanho do segmento 255.
  - Agora, independente do agrupamento por valores, detectamos o ponto médio REAL assim:

        primeiro_255 = menor índice i onde num_user[i] == 255
        ultimo_255   = maior índice i onde num_user[i] == 255

        centro = (primeiro_255 + ultimo_255) / 2

  Isso garante que uma pista perfeitamente reta NÃO será interpretada como curva.
*/

int main()
{
    int L;
    if (scanf("%d", &L) != 1)
        return 0;

    int padrao[] = {1, 3, 2, 3, 1};
    int M = sizeof(padrao) / sizeof(padrao[0]);

    int *midpoints = (int *)malloc(L * sizeof(int));
    int mid_count = 0;
    int lines_with_pattern = 0;

    for (int line = 0; line < L; line++)
    {
        int N;
        if (scanf("%d", &N) != 1)
            break;

        int *num_user = (int *)malloc(N * sizeof(int));
        for (int i = 0; i < N; i++)
            scanf("%d", &num_user[i]);

        // --- Agrupamento original mantido ---
        int *indices = (int *)malloc(N * sizeof(int));
        int aux = 0;

        for (int i = 0; i < N;)
        {
            int valor = num_user[i];
            int cont = 1;

            while (i + cont < N && num_user[i + cont] == valor)
                cont++;

            int indice = 0;
            if (valor == 0) indice = 1;
            else if (valor == 128) indice = 2;
            else if (valor == 255) indice = 3;

            indices[aux] = indice;

            aux++;
            i += cont;
        }

        int match_pos = KMP(padrao, M, indices, aux);

        if (match_pos != -1)
        {
            lines_with_pattern++;

            /*
                SOLUÇÃO DEFINITIVA:
                Ignoramos agrupamento e encontramos o ponto médio REAL da pista:
                posição do primeiro e último 255 na linha inteira.
            */

            int first255 = -1;
            int last255 = -1;

            for (int i = 0; i < N; i++)
            {
                if (num_user[i] == 255)
                {
                    if (first255 == -1)
                        first255 = i;

                    last255 = i;
                }
            }

            // Se houver pista (segmento vermelho real)
            if (first255 != -1)
            {
                int centro = (first255 + last255) / 2;
                midpoints[mid_count++] = centro;
            }
        }

        free(indices);
        free(num_user);
    }

    int required = (int)ceil(0.7 * L);
    if (lines_with_pattern < required || mid_count == 0)
    {
        printf("Resultado: Formato da pista nao estimado.\n");
        free(midpoints);
        return 0;
    }

    double sum_diffs = 0.0;
    int diffs_count = 0;

    for (int i = 0; i + 1 < mid_count; i++)
    {
        sum_diffs += (midpoints[i + 1] - midpoints[i]);
        diffs_count++;
    }

    double avg_delta = 0.0;
    if (diffs_count > 0)
        avg_delta = sum_diffs / diffs_count;

    double threshold = 0.5;

    if (avg_delta > threshold)
        printf("Resultado: Curva a esquerda.\n");
    else if (avg_delta < -threshold)
        printf("Resultado: Curva a direita.\n");
    else
        printf("Resultado: Pista em linha reta.\n");

    free(midpoints);
    return 0;
}
